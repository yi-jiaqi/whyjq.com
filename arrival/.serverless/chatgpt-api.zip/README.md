Instruction:
1. Open Terminal
2. node server.js
Done!